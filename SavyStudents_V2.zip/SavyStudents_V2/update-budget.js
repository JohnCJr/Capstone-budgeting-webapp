// This code validates and sends user input to update their budget

document.addEventListener("DOMContentLoaded", () => {
    const budgetForm = document.getElementById('updateBudget');
    const errorMessage = document.getElementById('update-budget-error-msg');
 
    budgetForm.addEventListener('submit', (event) => {
        event.preventDefault(); 

        // Gather budget data entered by the user
        const totalBudget = document.getElementById('totalBudget').value;
        const foodBudget = document.getElementById('foodBudget').value;
        const utilityBudget = document.getElementById('utilityBudget').value;
        const entertainmentBudget = document.getElementById('entertainmentBudget').value;
        const otherBudget = document.getElementById('otherBudget').value;

        // Create the data object of user input values to be sent to the back-end
        const data = {
            total: totalBudget,
            food: foodBudget,
            utility: utilityBudget,
            entertainment: entertainmentBudget,
            other: otherBudget
        };

        // Send the data to the backend using fetch, update-budget is a temporary name
        fetch('/api/update-budget', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                // Redirect to the dashboard once successfully updated budget
                window.location.href = '/dashboard.html';
            } else {
                // Display an error message
                errorMessage.textContent = result.message;
                errorMessage.style.display = 'flex';

                // Resets the input fields
                document.getElementById('totalBudget').value = '';
                document.getElementById('foodBudget').value = '';
                document.getElementById('utilityBudget').value = '';
                document.getElementById('entertainmentBudget').value = '';
                document.getElementById('otherBudget').value = '';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            errorMessage.textContent = 'An error occurred. Please try again.';
            errorMessage.style.display = 'flex';

            // Resets the input fields
            document.getElementById('totalBudget').value = '';
            document.getElementById('foodBudget').value = '';
            document.getElementById('utilityBudget').value = '';
            document.getElementById('entertainmentBudget').value = '';
            document.getElementById('otherBudget').value = '';
        });
    });
});