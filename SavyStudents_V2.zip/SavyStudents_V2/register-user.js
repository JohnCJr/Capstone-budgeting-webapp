// This set of code will register a new user based on their input

document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById('registerForm');
    const errorMessage = document.getElementById('register-user-error-msg');

    registerForm.addEventListener('submit', (event) => {
        event.preventDefault(); 

        // Gather user data entered by the user
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const userEmail = document.getElementById('userEmail').value;
        const userName = document.getElementById('userName').value;
        const password = document.getElementById('password').value;
        const phoneNumber = document.getElementById('phoneNumber').value;

        // Create the data object from user input to be sent to the back-end
        const data = {
            firstName: firstName,
            lastName: lastName,
            email: userEmail,
            username: userName,
            password: password,
            phoneNumber: phoneNumber
        };

        // Send the data to the backend using fetch, register is a placeholder name
        fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                // Redirect to the sign-on page once successfully registered
                window.location.href = '/sign-on.html';
            } else {
                // Display an error message
                errorMessage.textContent = result.message;
                errorMessage.style.display = 'flex';

                // Resets user input fields, may need to change
                document.getElementById('firstName').value = "";
                document.getElementById('lastName').value = "";
                document.getElementById('userEmail').value = "";
                document.getElementById('userName').value = "";
                document.getElementById('password').value = "";
                document.getElementById('phoneNumber').value = "";

            }
        })
        .catch(error => {
            console.error('Error:', error);
            errorMessage.textContent = 'An error occurred. Please try again.';
            errorMessage.style.display = 'flex';

            // Resets user input fields, may need to change
            document.getElementById('firstName').value = "";
            document.getElementById('lastName').value = "";
            document.getElementById('userEmail').value = "";
            document.getElementById('userName').value = "";
            document.getElementById('password').value = "";
            document.getElementById('phoneNumber').value = "";

        });
    });

    // Format phone number input
    document.getElementById('phoneNumber').addEventListener('input', function (e) {
        const x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
    });
});